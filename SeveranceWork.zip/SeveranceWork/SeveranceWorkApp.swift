//
//  SeveranceWorkApp.swift
//  SeveranceWork
//
//  Created by Rayann chaghla on 17/02/2025.
//

import SwiftUI

@main
struct SeveranceWorkApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
